ulimit -c 0 > /dev/null 2>&1
